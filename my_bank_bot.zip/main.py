from keep_alive import keep_alive
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, ContextTypes, filters

BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"
ADMIN_ID = 6379065453

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("স্বাগতম! কীভাবে সাহায্য করতে পারি? 😊")

async def forward_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.message.from_user
    text = update.message.text
    msg = f"📩 মেসেজ এসেছে\n👤 User: {user.first_name} (@{user.username})\n🆔 ID: {user.id}\n💬: {text}"
    await context.bot.send_message(chat_id=ADMIN_ID, text=msg)

async def admin_reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        return
    try:
        user_id = int(context.args[0])
        message = " ".join(context.args[1:])
        await context.bot.send_message(chat_id=user_id, text=f"🛠️ Admin: {message}")
        await update.message.reply_text("✅ Message sent to user.")
    except:
        await update.message.reply_text("⚠️ Format: /reply user_id message")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("reply", admin_reply))
app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), forward_to_admin))

keep_alive()
app.run_polling()
